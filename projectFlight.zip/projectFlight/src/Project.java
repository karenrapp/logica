import java.util.Scanner;

public class Project {
    public static final int HOURS_DAY = 24;
    public static final int MINUTES_HOUR = 60;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        part1();
        part2();
        part3();
        part4();
    }


    public static void part1() {
        Scanner input = new Scanner(System.in);
            System.out.println("Hello! Welcome to Vacation Planner!");
            System.out.print("What is your name? ");
            String name = input.nextLine();
            System.out.print("Nice to meet you " + name + ", where are you travelling to? ");
            String city = input.nextLine();
            System.out.println("Great! "+ city + " sound like a great trip! ");
            System.out.println("**********");
            System.out.println("");
            System.out.println("");
            System.out.println("");}

            public static void part2() {
                Scanner input = new Scanner(System.in);
            System.out.print("How many days are you going to spend travelling? ");
            int days = input.nextInt();
            System.out.print("How much money, in USD, are you planning to spend on your trip? ");
            double money = input.nextDouble();
            System.out.print("What is the three letter currency symbol for your travel destination? ");
            String currency = input.next();
            System.out.print("How many "+ currency+ " are there in 1 USD? ");
            double conversionDollar = input.nextDouble();
            int hours = days*HOURS_DAY;
            int minutes = hours*MINUTES_HOUR;
            double moneyDay = money/days;
            double moneyDayConversion = moneyDay*conversionDollar;
            moneyDay = moneyDay*100;
            int valeu =(int) moneyDay;
            moneyDay=valeu/100.0;
            moneyDayConversion = moneyDayConversion*100;
            int valeu2 = (int) moneyDayConversion;
            moneyDayConversion=valeu2/100.0;

            System.out.println("If you are travelling for " + days + " days, that is the same as " + hours + " hours or " + minutes+ " minutes! ");
            System.out.println("If you are going to spend $ " + money + " USD, that means that per day you can spend up to $" + moneyDay + " USD! ");
            System.out.println("Your total budget in " + currency + " is $ " + money*conversionDollar +" "+  currency + ", which per day is $" + moneyDayConversion+ " " +currency+ "! ");
        System.out.println("**********");
            System.out.println("");
            System.out.println("");
            System.out.println("");
        }

        public static void part3() {
            Scanner input = new Scanner(System.in);
        System.out.print("What is the time difference, in hours, between your home and your destination?");
        int timeDif = input.nextInt();
        int residualHours = timeDif % 24;
        int timeDifNoon = (residualHours+12)%24;
        System.out.println("That means that when it is mignight at home, it will be " + residualHours + ":00 hours in your destination! And when it is noon ate home it will be  " +timeDifNoon+":00!");
        System.out.println("**********");
            System.out.println("");
            System.out.println("");
            System.out.println("");
    }
    public static void part4() {
        Scanner input = new Scanner(System.in);
        System.out.print("What is the area of your destination in km2?");
        int area = input.nextInt();
        double areaMiles = area*0.386102;
        areaMiles = areaMiles*100;
        int valeu = (int) areaMiles;
        areaMiles = valeu/100;

        System.out.println("In miles2 that is "+ areaMiles+ " !");
        System.out.println("**********");
        System.out.println("");
        System.out.println("");
        System.out.println("");
    }

}